using System.Diagnostics;
using System.Text;
using System.Text.Json;

class Program {
 static readonly HttpClient H=new(){Timeout=TimeSpan.FromSeconds(15)};
 static string Dir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),"SchoolITManager");
 static string Cfg=Path.Combine(Dir,"agent.json");
 class C { public string ServerUrl{get;set;}=""; public string DeviceToken{get;set;}=""; public int PollSeconds{get;set;}=10; }
 class P { public string? command{get;set;} }
 static async Task Main(){
  Directory.CreateDirectory(Dir); var c=Load();
  if(string.IsNullOrWhiteSpace(c.ServerUrl)){File.WriteAllText(Path.Combine(Dir,"SET_SERVER_URL.txt"),"ضع رابط Cloudflare Worker في agent.json ثم شغل البرنامج مرة أخرى.");return;}
  c.ServerUrl=c.ServerUrl.TrimEnd('/');
  if(string.IsNullOrWhiteSpace(c.DeviceToken)){
   try{
    var b=JsonSerializer.Serialize(new{machineName=Environment.MachineName,displayName=Environment.MachineName});
    var r=await H.PostAsync(c.ServerUrl+"/agent/register",new StringContent(b,Encoding.UTF8,"application/json"));
    if(!r.IsSuccessStatusCode)return;
    var x=JsonSerializer.Deserialize<Dictionary<string,JsonElement>>(await r.Content.ReadAsStringAsync());
    c.DeviceToken=x!["token"].GetString()!; Save(c);
   }catch{return;}
  }
  while(true){
   try{
    var b=JsonSerializer.Serialize(new{token=c.DeviceToken});
    var r=await H.PostAsync(c.ServerUrl+"/agent/poll",new StringContent(b,Encoding.UTF8,"application/json"));
    if(r.IsSuccessStatusCode){
     var p=JsonSerializer.Deserialize<P>(await r.Content.ReadAsStringAsync());
     if(p?.command=="shutdown"){Process.Start(new ProcessStartInfo("shutdown","/s /t 0"){UseShellExecute=false,CreateNoWindow=true});return;}
     if(p?.command=="restart"){Process.Start(new ProcessStartInfo("shutdown","/r /t 0"){UseShellExecute=false,CreateNoWindow=true});return;}
    }
   }catch{}
   await Task.Delay(TimeSpan.FromSeconds(Math.Max(5,c.PollSeconds)));
  }
 }
 static C Load(){try{return JsonSerializer.Deserialize<C>(File.ReadAllText(Cfg))??new C();}catch{return new C();}}
 static void Save(C c)=>File.WriteAllText(Cfg,JsonSerializer.Serialize(c,new JsonSerializerOptions{WriteIndented=true}));
}