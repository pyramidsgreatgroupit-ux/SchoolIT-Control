@echo off
schtasks /Delete /TN "School IT Manager Agent" /F
rmdir /S /Q "%ProgramData%\SchoolITManager"
echo Removed.
pause
