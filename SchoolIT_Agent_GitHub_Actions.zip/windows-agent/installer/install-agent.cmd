@echo off
if not exist "%~dp0SchoolIT.Agent.exe" (echo Put SchoolIT.Agent.exe beside this file.&pause&exit /b 1)
if not exist "%ProgramData%\SchoolITManager" mkdir "%ProgramData%\SchoolITManager"
copy /Y "%~dp0SchoolIT.Agent.exe" "%ProgramData%\SchoolITManager\SchoolIT.Agent.exe" >nul
set /p SERVER=Cloudflare Worker URL: 
> "%ProgramData%\SchoolITManager\agent.json" echo {"ServerUrl":"%SERVER%","DeviceToken":"","PollSeconds":10}
schtasks /Create /TN "School IT Manager Agent" /TR ""%ProgramData%\SchoolITManager\SchoolIT.Agent.exe"" /SC ONSTART /RU SYSTEM /F >nul
echo Installed. Restart Windows or run the EXE once as Administrator.
pause
