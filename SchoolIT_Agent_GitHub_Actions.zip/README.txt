SchoolIT Agent - GitHub Actions EXE Builder

هذا المجلد يبني ملف EXE حقيقي على Windows runner داخل GitHub Actions.
لا تحتاج Visual Studio أو جهاز Windows للتجميع.

الناتج:
SchoolIT.Agent.exe
Windows x64, self-contained, single-file.

بعد البناء:
- ضع EXE بجانب installer/install-agent.cmd.
- شغّل install-agent.cmd كمسؤول على كل جهاز.
- اكتب رابط Cloudflare Worker.
- الـAgent يسجل الجهاز تلقائيًا.
